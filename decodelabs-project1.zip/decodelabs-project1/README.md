# DecodeLabs — Project 1: Static Webpage Design

A clean, professional, fully responsive multi-page static website built with
semantic **HTML5** and pure **CSS3** — matching every requirement from the
DecodeLabs Frontend Project 1 brief.

## ✅ What this project covers (from the brief)

- **IA:** Logical sitemap — Home / About / Services / Contact
- **HTML:** Semantic tags (`<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`, `<footer>`). One `<h1>` per page.
- **CSS:** External stylesheet only. DRY + BEM-style class names. No inline styles. No IDs used for styling.
- **Layout:** CSS Grid for macro page structure, Flexbox for micro components.
- **Accessibility:** Alt text where needed, labels on every form input, high contrast colors, semantic landmarks.
- **Responsive:** Works on mobile, tablet, and desktop.
- **Quality:** Valid HTML, no console errors, clean separation of concerns.

## 📁 File structure

```
decodelabs-project1/
├── index.html       # Home
├── about.html       # About page
├── services.html    # Services + Project checklist
├── contact.html     # Contact form
├── css/
│   └── style.css    # Single external stylesheet
└── README.md
```

## ▶️ How to run

You don't need to install anything — it's pure HTML & CSS.

### Option 1 — Just open it
1. Unzip the folder.
2. Double-click **`index.html`**. It opens in your default browser. Done.

### Option 2 — Open in VS Code (recommended)
1. Install [Visual Studio Code](https://code.visualstudio.com/).
2. Install the **"Live Server"** extension (by Ritwick Dey).
3. `File → Open Folder…` → choose the `decodelabs-project1` folder.
4. Right-click `index.html` → **"Open with Live Server"**.
5. The site auto-opens at `http://127.0.0.1:5500/` and live-reloads on save.

### Option 3 — Any other editor
Sublime Text, Notepad++, Atom, WebStorm, Brackets — all work the same way.
Just open the folder and launch `index.html` in a browser.

## 🧪 Validation

- HTML: paste source into <https://validator.w3.org/> → should pass with zero errors.
- Performance / A11y / SEO: open Chrome DevTools → **Lighthouse** → Run audit.

## 📝 Notes
- All colors and spacing are defined as CSS custom properties at the top of
  `style.css` — change them in one place to re-theme the whole site.
- The contact form is front-end only (shows a confirmation alert on submit);
  hook it up to a backend in Project 2+.
